const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public"))); // Sirve la carpeta "public"

// Ruta para el formulario de contacto
app.post("/submit-message", (req, res) => {
  const { nombre, email, mensaje } = req.body;

  const data = `Nombre: ${nombre}\nEmail: ${email}\nMensaje: ${mensaje}\n---\n`;
  const filePath = path.join(__dirname, "mensajes.txt");

  // Guardar en mensajes.txt
  fs.appendFile(filePath, data, (err) => {
    if (err) {
      console.error("Error al guardar el mensaje:", err);
      return res.status(500).send("Error al guardar el mensaje.");
    }
    res.send("Mensaje enviado correctamente.");
  });
});

// Ruta por defecto para servir el archivo HTML principal (index.html)
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Configuración del puerto
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});
